<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=loginsek");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="images/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <title>YourStory</title>
</head>
<body>
    <div class="container mt-2">
        <h1 class="text-center">Form Tambah</h1>
        <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
            <label class="form-label">Gambar</label><br>
            <input type="file" name="gambar" class="form-control" required><br>

            <label class="form-label">Caption</label><br>
            <input type="textarea" name="caption" class="form-control" autocomplete="off" required><br>

            <label class="form-label">Lokasi</label><br>
            <input type="text" name="lokasi" class="form-control" autocomplete="off" required><br>

            <button type="submit" class="btn" style="background: linear-gradient(-135deg, #c850c0, #4158d0); color: white;" name="simpan">Simpan</button>
        </form>
    </div>
</body>
</html>